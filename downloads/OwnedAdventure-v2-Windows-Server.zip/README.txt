Owned Adventure v2 Server, Windows x64, self-contained .NET runtime. Cross-published; NOT executed on Windows. Unity client is NOT included.
Extract all files; run Server/MockServer.exe.
See docs/C-HUONG-DAN.md in the source archive or repository. Use only synthetic local accounts.
