Windows x64 tools only. Unity client NOT included. Cross-published, NOT tested on Windows.
Run Server/MockServer.exe for loopback mock. Run Manager/Manager.exe and select your own trusted client.
Local test account: demo / local-demo-only. Do not expose mock server publicly.
Full source and instructions are in the separate source-reports archive.
