Owned Adventure v2 Launcher, Windows x64, self-contained .NET runtime. Cross-published; NOT executed on Windows. Unity client is NOT included.
Extract all files; run Launcher/Launcher.exe.
See docs/C-HUONG-DAN.md in the source archive or repository. Use only synthetic local accounts.
