"""Functional checks against our own server/manager; never executes reference files."""
import subprocess,pathlib,time,urllib.request,urllib.error,json,tempfile,os
ROOT=pathlib.Path(__file__).resolve().parents[1]
DOTNET=os.environ.get('DOTNET','/workspace/dotnet/dotnet')
env=dict(os.environ,DOTNET_CLI_HOME='/workspace/dotnet-home',DOTNET_CLI_TELEMETRY_OPTOUT='1')
http=urllib.request.build_opener(urllib.request.ProxyHandler({}))
count=0
def check(ok,name):
 global count
 assert ok,name
 count+=1;print('PASS',name)
def request(path,body=None,token=None):
 headers={}
 if body is not None:headers['Content-Type']='application/json'
 if token:headers['Authorization']='Bearer '+token
 req=urllib.request.Request('http://127.0.0.1:5077'+path,data=body,headers=headers)
 try:
  with http.open(req,timeout=3) as r:return r.status,json.load(r)
 except urllib.error.HTTPError as e:return e.code,None
# Refuse to reuse or stop an existing server.
try:
 request('/health')
 raise RuntimeError('Port 5077 already serves HTTP; stop it yourself before this isolated test')
except urllib.error.URLError:pass
with tempfile.TemporaryDirectory() as temp:
 log=open(pathlib.Path(temp)/'server.log','w+')
 server=subprocess.Popen([DOTNET,str(ROOT/'src/MockServer/bin/Release/net10.0/MockServer.dll')],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:
  for _ in range(100):
   if server.poll() is not None:raise RuntimeError('Our mock server exited before readiness')
   try:
    code,data=request('/health')
    if code==200:break
   except (urllib.error.URLError,TimeoutError):pass
   time.sleep(.1)
  else:raise RuntimeError('Server readiness timeout')
  check(data['status']=='ok' and data['mode']=='local-mock','health payload')
  check(request('/world')[0]==401,'world requires authentication')
  check(request('/login',b'{"username":"demo","password":"wrong"}')[0]==401,'incorrect credentials rejected')
  check(request('/login',b'{broken')[0]==400,'malformed login rejected')
  check(request('/login',b'null')[0]==401,'null login rejected')
  code,data=request('/login',b'{"username":"demo","password":"local-demo-only"}')
  check(code==200 and len(data['token'])==64,'test login issues token')
  code,world=request('/world',token=data['token'])
  check(code==200 and world['map']=='meadow' and world['hp']==100,'authenticated world payload')
  check(request('/world',token='invalid')[0]==401,'unknown token rejected')
 finally:
  server.terminate()
  try:server.wait(timeout=5)
  except subprocess.TimeoutExpired:server.kill();server.wait()
  log.close()
 # Benign local test fixture, unrelated to reference game.
 client=pathlib.Path(temp)/'test client.sh';client.write_text('#!/bin/sh\nexec /bin/sleep 60\n');client.chmod(0o700)
 commands=f'start\nselect /does/not/exist\nselect "{client}"\nstart\nstart\nstatus\nstop\nstatus\nquit\n'
 p=subprocess.run([DOTNET,str(ROOT/'src/Manager/bin/Release/net10.0/Manager.dll')],input=commands,text=True,capture_output=True,timeout=15,env=env)
 check(p.returncode==0,'manager exits cleanly')
 check('Select your client first' in p.stdout and 'Client does not exist' in p.stdout,'manager handles missing selection and missing file')
 check('Started PID' in p.stdout and 'Running PID' in p.stdout,'manager launches selected client with spaces in path')
 check('Already running' in p.stdout,'manager rejects duplicate launch')
 check('Stopped.' in p.stdout and 'Exited:' in p.stdout,'manager stops only its own child and reports exit')
print(f'{count} functional checks passed')
