# Owned Adventure — phân tích IL2CPP và MVP độc lập

- [A: phân tích tĩnh và bản đồ module](docs/A-PHAN-TICH.md).
- [B: Unity/IL2CPP và ví dụ tự tạo](docs/B-UNITY-IL2CPP.md).
- [C: cài đặt, chạy, mod API, kiểm thử, đóng gói](docs/C-HUONG-DAN.md).
- [Trạng thái kiểm chứng](reports/VALIDATION.md).

Game mới dùng hình vuông/màu tự tạo; không sử dụng code, binary, hình ảnh hoặc thông tin đăng nhập của game tham khảo. Không phải bản phục hồi source game cũ.

Chạy phần C# trong môi trường hiện tại:

```bash
bash scripts/build-dotnet.sh
DOTNET_CLI_HOME=/workspace/dotnet-home /workspace/dotnet/dotnet run --project src/MockServer
```

Mở `UnityGame` bằng Unity 6.3 LTS, chọn **Owned Game → Create Bootstrap Scene**, rồi Play. Unity Editor chưa được cài/chạy trong môi trường này; xem giới hạn trong báo cáo. Không chạy EXE/DLL game tham khảo để kiểm thử MVP.
