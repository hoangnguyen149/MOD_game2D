using System;
using System.Collections;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using OwnedGame;
public sealed class LocalGame:MonoBehaviour,IModHost
{
    readonly World world=new World();
    Transform actor; string status="Offline — start the local mock server",token="",title="LOCAL ADVENTURE";
    bool showFps,online,busy; Color accent=Color.green; KeyCode cast=KeyCode.Space;
    float fps; int spawned;
    [Serializable] public sealed class ModSettings { public string theme="ocean";public bool fps=true;public string castKey="Space";public string hudTitle="MY LOCAL GAME"; }
    [Serializable] sealed class LoginResponse { public string token; }
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Boot(){if(FindFirstObjectByType<LocalGame>()==null)new GameObject("OwnedGame").AddComponent<LocalGame>();}
    void Awake(){
        Application.targetFrameRate=60;
        var cam=Camera.main;if(cam==null){cam=new GameObject("Camera").AddComponent<Camera>();cam.tag="MainCamera";}
        cam.transform.position=new Vector3(0,0,-10);cam.orthographic=true;cam.orthographicSize=6;cam.backgroundColor=new Color(.04f,.07f,.12f);
        for(int y=-5;y<=5;y++)for(int x=-9;x<=9;x++)Square("Tile",new Vector2(x,y),new Vector2(.97f,.97f),((x+y)&1)==0?new Color(.12f,.25f,.2f):new Color(.14f,.29f,.23f),0);
        actor=Square("Player",Vector2.zero,new Vector2(.6f,.8f),Color.white,2).transform;
        new SampleMod().Configure(this);ReloadMod();
    }
    GameObject Square(string name,Vector2 pos,Vector2 size,Color color,int order){
        var go=new GameObject(name);go.transform.position=pos;go.transform.localScale=size;
        var sr=go.AddComponent<SpriteRenderer>();sr.sprite=Sprite.Create(Texture2D.whiteTexture,new Rect(0,0,1,1),new Vector2(.5f,.5f),1);sr.color=color;sr.sortingOrder=order;return go;
    }
    void Update(){
        fps=Mathf.Lerp(fps,1/Mathf.Max(Time.unscaledDeltaTime,.001f),.1f);
        if(Input.GetKeyDown(KeyCode.Escape))world.Paused=!world.Paused;
        float x=(Input.GetKey(KeyCode.D)||Input.GetKey(KeyCode.RightArrow)?1:0)-(Input.GetKey(KeyCode.A)||Input.GetKey(KeyCode.LeftArrow)?1:0);
        float y=(Input.GetKey(KeyCode.W)||Input.GetKey(KeyCode.UpArrow)?1:0)-(Input.GetKey(KeyCode.S)||Input.GetKey(KeyCode.DownArrow)?1:0);
        world.Move(x,y,Time.deltaTime);actor.position=new Vector3(world.X,world.Y,0);
        if(Input.GetKeyDown(cast) && world.Cast())status="Local ability used (-5 MP)";
    }
    public void SetTheme(string theme){if(theme!="ocean" && theme!="sunset")throw new ArgumentException("theme must be ocean or sunset");accent=theme=="ocean"?Color.cyan:new Color(1,.55f,.25f);}
    public void ShowFps(bool enabled){showFps=enabled;}
    public void Bind(string action,string key){KeyCode parsed;if(action!="cast" || !Enum.TryParse(key,true,out parsed) || !Enum.IsDefined(typeof(KeyCode),parsed) || parsed==KeyCode.None)throw new ArgumentException("Invalid key binding");cast=parsed;}
    public void SetHudTitle(string text){title=string.IsNullOrWhiteSpace(text)?"LOCAL ADVENTURE":text.Substring(0,Math.Min(60,text.Length));}
    void ReloadMod(){
        var path=Path.Combine(Application.persistentDataPath,"mod.json");
        try{
            if(!File.Exists(path))File.WriteAllText(path,JsonUtility.ToJson(new ModSettings(),true));
            if(new FileInfo(path).Length>16384)throw new IOException("mod.json too large");
            var config=JsonUtility.FromJson<ModSettings>(File.ReadAllText(path));if(config==null)throw new ArgumentException("Invalid mod JSON");
            // Validate all fields before changing host state.
            KeyCode key;if((config.theme!="ocean"&&config.theme!="sunset") || !Enum.TryParse(config.castKey,true,out key) || !Enum.IsDefined(typeof(KeyCode),key) || key==KeyCode.None)throw new ArgumentException("Invalid mod settings");
            SetTheme(config.theme);ShowFps(config.fps);Bind("cast",config.castKey);SetHudTitle(config.hudTitle);status="Loaded mod.json";
        }catch(Exception e){status="Mod settings rejected: "+e.GetType().Name;}
    }
    IEnumerator Connect(){
        busy=true;online=false;token="";
        using(var req=new UnityWebRequest("http://127.0.0.1:5077/login","POST")){
            req.uploadHandler=new UploadHandlerRaw(Encoding.UTF8.GetBytes("{\"username\":\"demo\",\"password\":\"local-demo-only\"}"));req.downloadHandler=new DownloadHandlerBuffer();req.SetRequestHeader("Content-Type","application/json");req.timeout=5;
            yield return req.SendWebRequest();
            if(req.result!=UnityWebRequest.Result.Success){status="Mock login failed (start server)";busy=false;yield break;}
            LoginResponse response=null;try{response=JsonUtility.FromJson<LoginResponse>(req.downloadHandler.text);}catch(ArgumentException){}
            if(response==null || string.IsNullOrEmpty(response.token)){status="Invalid mock response";busy=false;yield break;}token=response.token;
        }
        using(var req=UnityWebRequest.Get("http://127.0.0.1:5077/world")){
            req.SetRequestHeader("Authorization","Bearer "+token);req.timeout=5;yield return req.SendWebRequest();online=req.result==UnityWebRequest.Result.Success;
            status=online?"Connected: local meadow":"Mock world request failed";
        }
        busy=false;
    }
    void OnGUI(){
        GUI.color=accent;GUI.Box(new Rect(12,12,350,125),title);GUI.color=Color.white;
        GUI.Label(new Rect(25,40,320,25),"HP "+world.Hp+" / 100     MP "+world.Mp+" / 50"+(showFps?"   FPS "+fps.ToString("F0"):""));
        GUI.Label(new Rect(25,65,320,25),"WASD / arrows · "+cast+" ability · Esc menu");
        GUI.Label(new Rect(25,90,320,40),status);
        if(world.Paused){
            GUI.Box(new Rect(Screen.width/2-150,Screen.height/2-135,300,265),"LOCAL MENU");
            GUILayout.BeginArea(new Rect(Screen.width/2-130,Screen.height/2-105,260,240));
            if(GUILayout.Button("Play / Resume"))world.Paused=false;
            #if UNITY_EDITOR || DEVELOPMENT_BUILD
            GUI.enabled=!busy;if(GUILayout.Button(online?"Reconnect mock":"Connect mock (demo)"))StartCoroutine(Connect());GUI.enabled=true;
#else
            GUILayout.Label("Offline edition");
#endif
            if(GUILayout.Button("Reload mod.json"))ReloadMod();
            GUILayout.Label("Settings: "+Application.persistentDataPath);
            if(GUILayout.Button("Quit"))Application.Quit();GUILayout.EndArea();
        }
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        GUILayout.BeginArea(new Rect(Screen.width-220,12,205,210),GUI.skin.box);
        GUILayout.Label("LOCAL DEVELOPMENT DEBUG");
        GUILayout.Label("Speed "+world.Speed.ToString("F1"));world.DebugSpeed(GUILayout.HorizontalSlider(world.Speed,1,12));
        if(GUILayout.Button("Heal HP / MP"))world.DebugHeal();
        if(GUILayout.Button("Test damage -10"))world.Damage(10);
        if(GUILayout.Button("Spawn local object") && spawned<50){Square("Debug object",new Vector2(world.X,world.Y),Vector2.one*.3f,Color.magenta,3);spawned++;}
        GUILayout.EndArea();
#endif
    }
}
