using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
public static class BuildGame
{
    [MenuItem("Owned Game/Create Bootstrap Scene")]
    public static void Scene(){Directory.CreateDirectory("Assets/Scenes");var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);EditorSceneManager.SaveScene(scene,"Assets/Scenes/Bootstrap.unity");EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/Scenes/Bootstrap.unity",true)};}
    public static void WindowsRelease(){Build(false);}
    public static void WindowsDevelopment(){Build(true);}
    static void Build(bool dev){
        Scene();PlayerSettings.companyName="OwnedLocal";PlayerSettings.productName="OwnedAdventure";
        PlayerSettings.insecureHttpOption=InsecureHttpOption.DevelopmentOnly;
        // Loopback mock uses HTTP: release is offline, development connects to mock.
        PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Standalone,ScriptingImplementation.IL2CPP);
        Directory.CreateDirectory("../Builds/Client");
        var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/Scenes/Bootstrap.unity"},locationPathName="../Builds/Client/OwnedAdventure.exe",target=BuildTarget.StandaloneWindows64,options=dev?BuildOptions.Development:BuildOptions.None});
        if(report.summary.result!=BuildResult.Succeeded)throw new Exception("Windows build failed: "+report.summary.result);
    }
}
