param([Parameter(Mandatory=$true)][string]$UnityEditor)
$ErrorActionPreference='Stop'
Set-Location (Join-Path $PSScriptRoot '..')
dotnet publish src/MockServer/MockServer.csproj -c Release -r win-x64 --self-contained true -o Builds/Server
if($LASTEXITCODE -ne 0){throw 'Server publish failed'}
dotnet publish src/Manager/Manager.csproj -c Release -r win-x64 --self-contained true -o Builds/Manager
if($LASTEXITCODE -ne 0){throw 'Manager publish failed'}
& $UnityEditor -batchmode -quit -projectPath "$PWD/UnityGame" -executeMethod BuildGame.WindowsRelease -logFile "$PWD/Builds/unity-build.log"
if($LASTEXITCODE -ne 0){throw 'Unity build failed; see Builds/unity-build.log'}
if(!(Test-Path Builds/Client/OwnedAdventure.exe)){throw 'Client artifact missing'}
Compress-Archive -Path Builds/Client,Builds/Server,Builds/Manager -DestinationPath Builds/OwnedAdventure-Windows.zip -Force
