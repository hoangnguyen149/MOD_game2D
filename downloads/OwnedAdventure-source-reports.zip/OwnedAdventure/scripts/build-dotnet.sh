#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export DOTNET_CLI_HOME="/workspace/dotnet-home"
export NUGET_PACKAGES="/workspace/nuget-packages"
export DOTNET_CLI_TELEMETRY_OPTOUT=1
DOTNET="${DOTNET:-/workspace/dotnet/dotnet}"
"$DOTNET" build src/MockServer/MockServer.csproj -c Release
"$DOTNET" build src/Manager/Manager.csproj -c Release
"$DOTNET" run --project tests/CoreChecks/CoreChecks.csproj -c Release
"$DOTNET" run --project tests/DebugChecks/DebugChecks.csproj -c Release
