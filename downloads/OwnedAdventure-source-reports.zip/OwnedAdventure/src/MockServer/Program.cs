using System.Collections.Concurrent;
using System.Net;
using System.Security.Cryptography;
var builder=WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("http://127.0.0.1:5077");
var app=builder.Build();
var sessions=new ConcurrentDictionary<string,DateTimeOffset>();
app.Use(async (context,next)=>{
    var ip=context.Connection.RemoteIpAddress;
    if(ip==null || !IPAddress.IsLoopback(ip)){context.Response.StatusCode=403;return;}
    await next(context);
});
app.MapGet("/health",()=>Results.Ok(new {status="ok",mode="local-mock"}));
app.MapPost("/login",(Login? login)=>{
    if(login is null || login.Username!="demo" || login.Password!="local-demo-only") return Results.Unauthorized();
    foreach(var pair in sessions) if(pair.Value<DateTimeOffset.UtcNow) sessions.TryRemove(pair.Key,out _);
    if(sessions.Count>=100) return Results.StatusCode(429);
    var token=Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
    sessions[token]=DateTimeOffset.UtcNow.AddMinutes(30);
    return Results.Ok(new {token,expiresIn=1800});
});
app.MapGet("/world",(HttpRequest request)=>{
    var auth=request.Headers.Authorization.ToString();
    if(!auth.StartsWith("Bearer ",StringComparison.Ordinal) || !sessions.TryGetValue(auth[7..],out var expiry) || expiry<DateTimeOffset.UtcNow) return Results.Unauthorized();
    return Results.Ok(new {map="meadow",hp=100,mp=50,server="local-mock"});
});
app.Run();
record Login(string Username,string Password);
