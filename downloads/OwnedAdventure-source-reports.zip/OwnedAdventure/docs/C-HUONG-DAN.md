# C — Game và công cụ mở rộng do người dùng kiểm soát

## Phạm vi và các mốc

| Mốc | Mã nguồn | Trạng thái |
|---|---|---|
| M0: phân tích tĩnh đầu vào | `tools/`, `reports/`, báo cáo A/B | Đã thực hiện; native chỉ khảo sát chọn lọc |
| M1: luật di chuyển/trạng thái và API mod | `UnityGame/Assets/Scripts/Core/World.cs` | Đã build và kiểm thử core .NET; không đồng nghĩa Unity player đã chạy |
| M2: client 2D | `UnityGame/Assets/Scripts/LocalGame.cs`, Editor/BuildGame.cs | Có source/bootstrap/build entry; chưa compile/chạy bằng Unity Editor |
| M3: server local và manager | `src/MockServer`, `src/Manager` | Đã build/chạy và kiểm thử chức năng trên Linux |
| M4: đóng gói Windows | `scripts/package-windows.ps1` | Server/manager đã cross-publish win-x64; client/package tổng chưa build/chạy |

Không có project gốc. Mọi logic MVP được viết mới; không tuyên bố giống giao thức, vật lý hay trải nghiệm của game tham khảo. Mock server trả snapshot mẫu, không đồng bộ chuyển động nhiều người chơi. Manager là công cụ dòng lệnh C#, chưa có giao diện desktop.

## Công cụ và phiên bản

Chọn **Unity 6.3 LTS**: trang hỗ trợ Unity ghi được hỗ trợ tới tháng 12/2027. Baseline project `6000.3.0f1` có trang release chính thức; nên cập nhật patch 6.3 LTS hiện hành bằng Unity Hub khi chuẩn bị phát hành và kiểm thử lại. Không dùng Unity 2020 của game cũ để tạo game mới. Unity C# dùng runtime/API compatibility của Unity; **không đưa assembly net10.0 vào client Unity**. Core dùng chung ở dạng source, không tham chiếu DLL .NET 10.

Chọn **.NET 10 LTS** cho mock server, manager, kiểm thử, hỗ trợ đến 14/11/2028 theo Microsoft. SDK đã cài và dùng: **10.0.403**; pin trong `global.json`. Archive SDK được đối chiếu SHA-512 với release manifest Microsoft. Không cần API key hay tài khoản thật. Server chỉ bind loopback `127.0.0.1:5077` và kiểm tra IP nguồn loopback.

Nguồn đã kiểm tra:

- https://unity.com/releases/unity-6/support
- https://unity.com/releases/editor/whats-new/6000.3.0f1
- https://dotnet.microsoft.com/en-us/platform/support/policy
- https://builds.dotnet.microsoft.com/dotnet/release-metadata/10.0/releases.json
- https://docs.unity3d.com/6000.3/Documentation/Manual/windows-requirements-and-compatibility.html
- https://docs.unity3d.com/6000.3/Documentation/ScriptReference/PlayerSettings-insecureHttpOption.html

## Cấu trúc repository

```text
UnityGame/
  Assets/Scripts/Core/World.cs     # di chuyển, HP/MP, IMod/IModHost, SampleMod
  Assets/Scripts/LocalGame.cs      # map thủ tục, nhân vật, HUD/menu, config, mock client
  Assets/Editor/BuildGame.cs      # sinh scene và build Windows
  Packages/manifest.json
  ProjectSettings/ProjectVersion.txt
src/
  Core/Core.csproj                # compile cùng source core với .NET
  MockServer/                     # ASP.NET Core, loopback-only
  Manager/                        # chọn client, start/stop/status
tests/
  CoreChecks/                     # 19 kiểm tra hành vi core/release
  DebugChecks/                    # 4 kiểm tra debug
  smoke.py                        # 13 kiểm tra HTTP/process thực tế
scripts/
  build-dotnet.sh
  package-windows.ps1
tools/                            # static-only scripts cho đầu vào tham khảo
reports/                          # hash/PE/call sites/kết quả kiểm tra
docs/                             # A, B, C
```

Dùng checkout hiện tại, không cần tạo Git worktree. File game tham khảo ở ngoài repository (`/workspace/reference-complete`); không copy chúng vào Assets. Chưa tạo commit hoặc push.

## Cài đặt và chạy C#

Trên máy Windows cài .NET 10 SDK chính thức (10.0.403 hoặc patch tương thích global.json). Trên cloud SDK tại `/workspace/dotnet`. Không đổi HOME của hệ thống. Cloud cần `DOTNET_CLI_HOME=/workspace/dotnet-home` và cache NuGet tại `/workspace/nuget-packages` do home gốc chỉ đọc. Lệnh .NET cần quyền thực thi hỗ trợ mutex/socket; trong phiên này đã dùng luồng nâng quyền của công cụ để build/run, không tắt sandbox hoặc TLS.

```bash
cd /workspace/MOD_game2D
bash scripts/build-dotnet.sh
# Server ở foreground; Ctrl-C để dừng:
DOTNET_CLI_HOME=/workspace/dotnet-home /workspace/dotnet/dotnet run --project src/MockServer
# Terminal khác:
DOTNET_CLI_HOME=/workspace/dotnet-home /workspace/dotnet/dotnet run --project src/Manager
```

Windows PowerShell:

```powershell
dotnet build src/MockServer -c Release
dotnet build src/Manager -c Release
dotnet run --project tests/CoreChecks -c Release
dotnet run --project tests/DebugChecks -c Release
dotnet run --project src/MockServer
# Terminal khác:
dotnet run --project src/Manager
```

Manager nhận `select "C:\Games\OwnedAdventure\OwnedAdventure.exe"`, `start`, `status`, `stop`, `quit`. Chọn client tin cậy do bạn build; tool không xác minh chữ ký client. Tool dùng ProcessStartInfo.UseShellExecute=false, không inject DLL, không đọc/sửa bộ nhớ. Stop chỉ xử lý tiến trình con đã mở; thử CloseMainWindow rồi kill cây tiến trình sau timeout. Thoát manager cũng đóng client con. Không tự tìm và kill các game khác.

Mock tài khoản công khai dành riêng local: username `demo`, password `local-demo-only`. Đây là dữ liệu thử nghiệm tự tạo, không lấy từ archive. `/health` trả trạng thái JSON; `POST /login` nhận JSON; `GET /world` cần `Authorization: Bearer ...`. Token ngẫu nhiên có thời hạn 30 phút, lưu trong RAM; mất khi restart. Tối đa 100 session chưa hết hạn. Không có lưu tài khoản thật, API đăng ký hoặc dịch vụ production. Client không lưu token lên disk.

Không mở cổng server ra mạng công cộng. Không có endpoint debug phía server. HP/MP/movement trong client là mô phỏng local; snapshot server không phải server-authoritative gameplay. Release client là offline; kết nối HTTP mock chỉ hiện ở Editor/Development Build. Không hạ TLS để gọi dịch vụ bên ngoài.

## Mở và chạy Unity

1. Cài Unity Hub và Unity Editor **6000.3 LTS**, có quyền dùng Unity hợp lệ. Để build Windows IL2CPP, dùng Windows 10/11 x64, cài Windows Build Support (IL2CPP), Visual Studio 2022 với C++ desktop tools và Windows SDK theo yêu cầu Unity. Build bằng Windows là đường dẫn được hỗ trợ trong hướng dẫn này; không giả định Linux có thể cross-build Windows IL2CPP.
2. Add project từ thư mục `UnityGame`. Project có manifest modules tối thiểu; Editor sẽ sinh Library, settings và .meta còn thiếu. Các file tự sinh này chưa được kiểm chứng tại cloud. Nếu Hub yêu cầu nâng patch trong 6.3, ghi lại version mới và kiểm thử lại.
3. Giữ **Active Input Handling = Input Manager (Old)** hoặc **Both**, vì MVP dùng `UnityEngine.Input`. Không cần package Input System. Nếu template mặc định dùng New only, đổi trong Project Settings → Player → Other Settings rồi restart Editor.
4. Chọn **Owned Game → Create Bootstrap Scene**. Nó tạo `Assets/Scenes/Bootstrap.unity`, đặt vào Build Settings. Đây là tác vụ có chủ đích của project mới; chưa có scene người dùng cần bảo toàn. Runtime bootstrap tự tạo camera, map, nhân vật; không cần prefab hoặc tài nguyên ngoài.
5. Play: menu lúc đầu, chọn Play/Resume; di chuyển WASD/mũi tên, Space dùng MP; Esc bật/tắt menu. Map giới hạn x ±9, y ±5; tốc độ chéo chuẩn hóa. HP/MP hiện trên HUD. Trong Editor, bật **Allow downloads over HTTP = Development Only** nếu cần mock (build script đặt khi build), khởi động server rồi Connect mock. Tên server, trạng thái lỗi được hiển thị; timeout 5 giây.
6. Không đòi Unity Editor tải hoặc dùng binary game tham khảo.

Nếu project không compile, đọc Console trước khi build: phần Unity chưa được compiler thật kiểm tra trong phiên này. Chưa có kết quả hình ảnh, hiệu năng, focus/input, scene/player hoặc HTTP client tích hợp để bảo đảm.

## API mod và mod mẫu

`IMod.Configure(IModHost)` là API C# do game sở hữu. `SampleMod` được đăng ký tường minh trong `Awake`; có thể thêm mod do bạn kiểm soát bằng lớp implement IMod rồi đăng ký trong source và rebuild player. IL2CPP AOT không mặc định hỗ trợ tải DLL C# mới tùy ý lúc chạy; không dùng Assembly.Load/injection. Các mod được đăng ký trực tiếp nên stripping có thể theo references; plugin reflection/generic mới cần preserve/AOT coverage riêng.

Mod dữ liệu runtime: `mod.json` trong `Application.persistentDataPath` (đường dẫn được hiển thị ở menu; Windows thường dưới `%USERPROFILE%\AppData\LocalLow\OwnedLocal\OwnedAdventure`). Game tạo file mẫu nếu chưa có:

```json
{
  "theme": "ocean",
  "fps": true,
  "castKey": "Space",
  "hudTitle": "MY LOCAL GAME"
}
```

Đổi theme sang `sunset`, fps false, castKey `F`, hudTitle tùy chọn, rồi Reload mod.json. Đây là thay HUD/theme/phím kỹ năng qua API chính thức. Không thay phím di chuyển ở MVP. File giới hạn 16 KiB; chỉ chấp nhận theme trong allowlist và KeyCode hợp lệ; kiểm tra trước khi áp dụng, lỗi được báo trên HUD. File sai không ngăn game chạy. Không tải code/URL hay thực thi script từ JSON.

## Debug và bản release

Trong Editor hoặc Development Build, bảng debug chỉnh speed 1–12, hồi HP/MP, gây damage thử và spawn tối đa 50 hình vuông. `World.DebugSpeed/DebugHeal` và GUI debug được bao bởi `UNITY_EDITOR || DEVELOPMENT_BUILD`; ký hiệu `LOCAL_TESTS` chỉ dùng trong project kiểm thử riêng. **Không thêm LOCAL_TESTS vào Unity Player**. Bản release thông thường bỏ API và UI debug; bài test reflection đã xác minh điều này cho core .NET release, **chưa xác minh binary Unity release**.

Không có cheat cho game tham khảo. Giới hạn local của debug hiện dựa vào kiến trúc game offline và mock loopback; nếu sau này thêm server thật phải thiết kế authority và quyền riêng, không giữ các command debug trong client release.

## Kiểm thử và xử lý lỗi

Đã chạy 19 core + 4 debug + 13 chức năng; chi tiết `reports/VALIDATION.md`. Test smoke Python hiện dành cho Linux/cloud, dùng client fixture `/bin/sleep`, không phải Windows GUI hay Unity client. Cần server build Release trước; test từ chối dùng lại server đang có trên 5077 để tránh dừng nhầm tiến trình. Script dừng server/fixture do nó mở.

```bash
python tests/smoke.py
```

Lỗi thường gặp: server chưa chạy/cổng bận → xem log server và kiểm tra `/health`; sai token → đăng nhập demo lại; HTTP bị Unity chặn → chỉ bật Development Only cho Editor/dev; JSON sai/key sai → sửa mod.json rồi Reload; .NET home read-only → dùng DOTNET_CLI_HOME; thiếu Windows IL2CPP module/C++/SDK → cài qua Hub/VS installer; client path sai → manager báo lỗi, chọn lại.

Kiểm tra Unity còn phải làm: compile sạch Editor; scene boot; phím/menu/pause; diagonal/clamp hình ảnh; HUD/theme/FPS/reload config hỏng; login/world và timeout; debug spawn cap; build development; build release và kiểm tra không có debug; chạy Windows cả từ Explorer và manager. Không đánh dấu danh sách này đã pass.

## Build và đóng gói Windows

Từ PowerShell tại repository:

```powershell
./scripts/package-windows.ps1 -UnityEditor 'C:\Program Files\Unity\Hub\Editor\6000.3.0f1\Editor\Unity.exe'
```

Script publish server và manager self-contained win-x64, gọi Unity batchmode `BuildGame.WindowsRelease`, kiểm exit/result và client EXE, sau đó nén **cả thư mục** client/server/manager. Không chỉ copy EXE Unity: phải giữ UnityPlayer, GameAssembly, `_Data` và phụ thuộc do Unity sinh. Release offline không cần server để chơi.

Development client riêng để kiểm mock/debug:

```powershell
& $UnityEditor -batchmode -quit -projectPath "$PWD/UnityGame" -executeMethod BuildGame.WindowsDevelopment -logFile "$PWD/Builds/unity-development.log"
```

Hai lệnh build hiện cùng output `Builds/Client`: đóng gói ngay từng bản hoặc dùng thư mục riêng, không trộn development vào release. `Scene()` hiện tạo mới Bootstrap; chỉ dùng trong project độc lập này, không chạy trên scene khác chưa lưu. Script packaging chưa chạy trên Windows.

Trong phiên này, đã cross-publish thành công self-contained **Server/MockServer.exe** và **Manager/Manager.exe** dưới `Builds`. Gói công cụ Windows kèm theo chỉ gồm hai ứng dụng đó, **không có Unity client**. Cross-publish không chứng minh chạy được trên Windows; cần kiểm thử đích. Không ký Authenticode/installer trong MVP. Khi phát hành thật: kiểm tra release/dev separation trên artifact, chạy smoke Windows, thêm version/signing nếu có chứng thư và quyết định kênh phân phối.
